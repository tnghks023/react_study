import React from 'react';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import styled from 'styled-components';

import MainPage       from './component/page/MainPage';
import PostWrite      from './component/page/PostWrite';
import PostView       from './component/page/PostView';
import JsonWrite      from './component/page/JsonWrite';

const MainTitle = styled.p`
  font-size:        24px;
  font-weight:      bold;
  text-align:       center;
`;

function App(props) {
  return (
    <BrowserRouter>
      <MainTitle>게시글 관리</MainTitle>
      <Routes>
        <Route path="/"            element={<MainPage   />} />
        <Route path="post-write"   element={<PostWrite  />} />
        <Route path="post/:postId" element={<PostView   />} />
        <Route path="json-write"   element={<JsonWrite  />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
