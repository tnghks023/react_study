import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import styled from 'styled-components';
import CommentList from '../list/CommentList';
import TextInput from '../ui/TextInput';
import Button from '../ui/Button';
import data from '../../data.json';

const Wrapper = styled.div`
    padding:            16px;
    width:              calc(100% - 32px);
    display:            flex;
    flex-decoration:    column;
    align-items:        center;
    justify-content:    center;
`;

const Container = styled.div`
    width:              100%;
    max-width:          720px;
    & > * {
        :not(:last-clild) {
            margin-bottom:      16px;
        }
    }
`;

const PostContainer = styled.div`
    padding:            10px 16px;
    border:             1px solid grey;
    border-radius:      10px;
    margin-top:         20px;
`;

const TitleText = styled.p`
    font-size:          28px;
    font-weight:        600;
`;

const ContentText = styled.p`
    font-size:          20px;
    line-height:        32px;
    white-space:        pre-wrap;   
`;

const CommentLabel = styled.p`
    font-size:          20px;;
    font-weight:        600;
    color:              orange;
`;

const PostView = (props) => {
    const navigate      = useNavigate();
    const { postId }    = useParams();

    // data.json 파일에서 조회하고자 하는 id와 같은 정보를 찾아서 post에 저장한다.
    const post = data.find( (item) => {
        return item.id == postId;
    });

    const [comment, setComment] = useState('');

    return (
        <Wrapper>
            <Container>
                <h1>게시글 상세 정보</h1>
                <Button title="처음으로" onClick={() => {navigate("/")}} />
                    <PostContainer>
                        <TitleText>{post.title}</TitleText>
                        <ContentText>{post.content}</ContentText>
                    </PostContainer>

                    <CommentLabel>댓글</CommentLabel>
                    {/* <CommentList comments={post.comments}/> */}

                    <TextInput height={50} value={comment} 
                                onChange={(event) => {setComment(event.target.value); console.log({comment}); }} />
                    <br/><br/>
                    <Button title="댓글작성" onClick={() => {navigate("/"); }} />
            </Container>
        </Wrapper>
    );
};

export default PostView;
