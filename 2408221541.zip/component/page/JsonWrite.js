import React, { useState } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import TextInput from '../ui/TextInput';
import Button from '../ui/Button';

const Wrapper = styled.div`
    padding:            16px;
    width:              calc(100% - 32px);
    display:            flex;
    flex-direction:     column;
    align-items:        center;
    justify-content:    center;
`;

const Container = styled.div`
    width:              100%;
    max-width:          740px;
    & > * {
        :not(:last-child) {
            margin-bottom:  16px;
        }
    }
`;


const JsonWrite = () => {
    const [title,   setTitle]   = useState('');
    const [content, setContent] = useState('');

    const onSubmit = () => {
        axios.post('http://localhost:3001/posts', {
            title:      title,
            content:    content,
        })
    };

    return (
        <Wrapper className='container'>
            <Container>
                <h1>Json Server로 데이터 보내서 저장시키기</h1>
                <div className='titleAll'>
                    <label className='title'><h2>제 목</h2></label>
                    <TextInput className="titleInput" height={20} vlaue={title}
                                onChange={(event) => {setTitle(event.target.value); }} />
                </div>
                <div className='contentAll'>
                    <label className='content'><h2>내 용</h2></label>
                    <TextInput className="contentInput" height={200} vlaue={content}
                                onChange={(event) => {setContent(event.target.value); }} />
                </div>
                <Button className="btn" title="글쓰기"  onClick={onSubmit} >글쓰기</Button>
            </Container>
        </Wrapper>
    );
};

export default JsonWrite;
